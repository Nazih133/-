import  React from 'react';
import { Sun } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-green-700 via-green-600 to-green-500 text-white py-6 shadow-lg">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-white bg-opacity-20 p-2 rounded-full">
            <Sun size={28} className="text-yellow-300" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">حاسبة الطاقة الشمسية</h1>
            <p className="text-xs text-green-100">تطوير: م. خالد جمال عبدالمقصود</p>
          </div>
        </div>
        <div className="text-sm bg-white bg-opacity-10 px-3 py-1 rounded-full">
          Solar Energy Calculator
        </div>
      </div>
    </header>
  );
}
 