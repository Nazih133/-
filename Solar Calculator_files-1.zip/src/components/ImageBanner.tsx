import  React from 'react';

export default function ImageBanner() {
  return (
    <div className="w-full h-48 md:h-64 lg:h-80 rounded-xl overflow-hidden shadow-lg mb-8">
      <img 
        src="https://images.unsplash.com/photo-1522444195799-478538b28823?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVscyUyMG9uJTIwaG9tZSUyMHJvb2Z8ZW58MHx8fHwxNzQ2NzI3NTkxfDA&ixlib=rb-4.1.0&fit=crop&w=1200&h=400&q=80"
        alt="أنظمة الطاقة الشمسية للمنازل والمباني"
        className="w-full h-full object-cover"
      />
    </div>
  );
}
 