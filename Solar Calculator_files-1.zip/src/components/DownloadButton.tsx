import  React from 'react';
import { Download } from 'lucide-react';

export default function DownloadButton() {
  const downloadApp = () => {
    const link = document.createElement('a');
    link.href = window.location.href;
    link.download = 'حاسبة-الطاقة-الشمسية.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <button 
      onClick={downloadApp}
      className="fixed top-4 left-4 z-50 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-full shadow-md flex items-center gap-2 text-sm"
    >
      <Download size={16} />
      <span>تنزيل التطبيق</span>
    </button>
  );
}
 