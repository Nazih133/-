import  React, { useState } from 'react';
import { Plus, Trash } from 'lucide-react';
import type { Device } from '../types';

interface DeviceInputProps {
  devices: Device[];
  setDevices: React.Dispatch<React.SetStateAction<Device[]>>;
}

export default function DeviceInput({ devices, setDevices }: DeviceInputProps) {
  const [device, setDevice] = useState('');
  const [power, setPower] = useState('');
  const [hours, setHours] = useState('');

  const addDevice = () => {
    if (device && power && hours) {
      const newDevice: Device = {
        id: Date.now().toString(),
        name: device,
        power: parseFloat(power),
        hours: parseFloat(hours)
      };
      setDevices([...devices, newDevice]);
      setDevice('');
      setPower('');
      setHours('');
    }
  };

  const removeDevice = (id: string) => {
    setDevices(devices.filter(d => d.id !== id));
  };

  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-4 text-gray-800">إضافة الأجهزة</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">اسم الجهاز</label>
          <input
            type="text"
            value={device}
            onChange={(e) => setDevice(e.target.value)}
            placeholder="مثال: تلفزيون"
            className="input-field"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">القدرة (واط)</label>
          <input
            type="number"
            value={power}
            onChange={(e) => setPower(e.target.value)}
            placeholder="مثال: 100"
            className="input-field"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">ساعات التشغيل</label>
          <input
            type="number"
            value={hours}
            onChange={(e) => setHours(e.target.value)}
            placeholder="مثال: 5"
            className="input-field"
          />
        </div>
      </div>
      
      <button onClick={addDevice} className="btn-primary flex items-center justify-center gap-2">
        <Plus size={18} />
        <span>إضافة جهاز</span>
      </button>

      {devices.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-medium mb-2 text-gray-700">الأجهزة المضافة:</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead className="bg-gray-100 text-gray-700">
                <tr>
                  <th className="px-4 py-2 rounded-r-lg">الجهاز</th>
                  <th className="px-4 py-2">القدرة (واط)</th>
                  <th className="px-4 py-2">ساعات التشغيل</th>
                  <th className="px-4 py-2 rounded-l-lg">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {devices.map((d) => (
                  <tr key={d.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-4 py-3">{d.name}</td>
                    <td className="px-4 py-3">{d.power}</td>
                    <td className="px-4 py-3">{d.hours}</td>
                    <td className="px-4 py-3">
                      <button 
                        onClick={() => removeDevice(d.id)}
                        className="text-red-600 hover:text-red-800 transition"
                        aria-label="حذف الجهاز"
                      >
                        <Trash size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
 