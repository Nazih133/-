import  React from 'react';
import { Battery, Zap, Sun, Activity } from 'lucide-react';
import type { CalculationResult } from '../types';

interface ResultsProps {
  results: CalculationResult | null;
}

export default function CalculationResults({ results }: ResultsProps) {
  if (!results) return null;
  
  const { dailyConsumption, panelsRequired, batteryCapacity, inverterSize } = results;
  
  const resultItems = [
    { 
      icon: <Zap size={24} className="text-yellow-500" />, 
      label: "الاستهلاك اليومي", 
      value: `${dailyConsumption.toFixed(2)} واط-ساعة`,
      description: "إجمالي الطاقة المستهلكة يوميًا"
    },
    { 
      icon: <Sun size={24} className="text-orange-500" />, 
      label: "عدد الألواح الشمسية", 
      value: `${Math.ceil(panelsRequired)} لوح`,
      description: "لوح شمسي 400 واط"
    },
    { 
      icon: <Battery size={24} className="text-green-500" />, 
      label: "سعة البطاريات", 
      value: `${batteryCapacity.toFixed(2)} أمبير-ساعة`,
      description: "بطاريات 12 فولت"
    },
    { 
      icon: <Activity size={24} className="text-blue-500" />, 
      label: "حجم العاكس (انفرتر)", 
      value: `${inverterSize.toFixed(2)} واط`,
      description: "بهامش أمان 20%"
    }
  ];

  return (
    <div className="card bg-gradient-to-br from-green-50 to-green-100 border border-green-200">
      <h2 className="text-xl font-bold mb-6 text-green-800">نتائج الحساب</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {resultItems.map((item, index) => (
          <div key={index} className="glass-card p-4">
            <div className="flex items-center gap-3 mb-2">
              {item.icon}
              <h3 className="font-bold text-gray-800">{item.label}</h3>
            </div>
            <p className="text-xl font-bold text-green-700">{item.value}</p>
            <p className="text-xs text-gray-600 mt-1">{item.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
 