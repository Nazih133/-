import  React from 'react';
import { Shield } from 'lucide-react';

export default function CopyrightBadge() {
  return (
    <div className="fixed bottom-4 left-4 z-50">
      <div className="bg-white bg-opacity-90 backdrop-blur-sm rounded-full py-1 px-3 shadow-md flex items-center text-xs text-gray-700 border border-gray-200">
        <Shield size={12} className="text-green-600 mr-1" />
        <span>م. خالد جمال عبدالمقصود &copy; {new Date().getFullYear()}</span>
      </div>
    </div>
  );
}
 