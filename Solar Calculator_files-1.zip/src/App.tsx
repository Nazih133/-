import  React, { useState } from 'react';
import Header from './components/Header';
import DeviceInput from './components/DeviceInput';
import CalculationResults from './components/CalculationResults';
import ImageBanner from './components/ImageBanner';
import { calculateSolarRequirements } from './utils/calculations';
import type { Device, CalculationResult } from './types';
import { Calculator } from 'lucide-react';
import CopyrightBadge from './components/CopyrightBadge';
import DownloadButton from './components/DownloadButton';

function App() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [results, setResults] = useState<CalculationResult | null>(null);

  const calculateResults = () => {
    if (devices.length === 0) return;
    const calculationResults = calculateSolarRequirements(devices);
    setResults(calculationResults);
  };

  return (
    <div className="min-h-screen bg-gray-50 relative">
      <CopyrightBadge />
      <DownloadButton />
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <ImageBanner />
        
        <div className="grid grid-cols-1 gap-8">
          <DeviceInput devices={devices} setDevices={setDevices} />
          
          {devices.length > 0 && (
            <button 
              onClick={calculateResults}
              className="btn-primary max-w-md mx-auto flex items-center justify-center gap-2 text-lg"
            >
              <Calculator size={20} />
              <span>حساب متطلبات النظام الشمسي</span>
            </button>
          )}
          
          {results && <CalculationResults results={results} />}
        </div>

        <div className="mt-12 text-center text-sm text-gray-600">
          <p>هذه الحسابات تقريبية وتعتمد على معدل 5 ساعات سطوع شمسي فعال يوميًا.</p>
          <p>يُنصح بالتواصل مع فني متخصص للحصول على تقييم دقيق لاحتياجاتك.</p>
        </div>
      </main>
      
      <footer className="bg-green-800 text-white py-6 mt-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-xl font-bold mb-2">حاسبة الطاقة الشمسية</h3>
              <p className="text-green-200 text-sm">تطبيق لحساب متطلبات الطاقة الشمسية للمنازل والمنشآت</p>
            </div>
            <div className="text-center md:text-right">
              <p className="mb-1">تم التطوير بواسطة <span className="font-bold">م. خالد جمال عبدالمقصود</span></p>
              <p className="text-xs text-green-200">&copy; {new Date().getFullYear()} جميع الحقوق محفوظة</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
 