export  interface Device {
  id: string;
  name: string;
  power: number;
  hours: number;
}

export interface CalculationResult {
  dailyConsumption: number;
  panelsRequired: number;
  batteryCapacity: number;
  inverterSize: number;
}
 