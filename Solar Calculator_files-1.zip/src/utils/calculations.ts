import  type { Device, CalculationResult } from '../types';

export function calculateSolarRequirements(devices: Device[]): CalculationResult {
  // Calculate total daily consumption (Watt-hours)
  const dailyConsumption = devices.reduce((total, device) => {
    return total + (device.power * device.hours);
  }, 0);
  
  // Calculate number of solar panels needed (using 400W panels, 5 hours effective sun)
  const dailyEnergyPerPanel = 400 * 5 * 0.8; // 400W panel, 5 peak sun hours, 80% efficiency
  const panelsRequired = dailyConsumption / dailyEnergyPerPanel;
  
  // Calculate battery capacity (Amp-hours) for 1 day autonomy at 12V
  const batteryCapacity = (dailyConsumption / 12) * 1.2; // 12V system, 20% safety margin
  
  // Calculate inverter size with 20% safety margin
  const maxPowerAtOnce = devices.reduce((max, device) => {
    return Math.max(max, device.power);
  }, 0);
  const inverterSize = maxPowerAtOnce * 1.2; // 20% safety margin
  
  return {
    dailyConsumption,
    panelsRequired,
    batteryCapacity,
    inverterSize
  };
}
 