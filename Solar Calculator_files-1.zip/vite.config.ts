import  { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    // Bundle all CSS and JS files
    cssCodeSplit: false,
    // Minify
    minify: 'terser',
    // Enable sourcemaps for production
    sourcemap: false
  }
});
 